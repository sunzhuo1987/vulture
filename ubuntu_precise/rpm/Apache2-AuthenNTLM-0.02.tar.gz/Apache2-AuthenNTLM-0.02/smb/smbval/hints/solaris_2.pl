$self->{CCFLAGS} = "-DSOLARIS";
